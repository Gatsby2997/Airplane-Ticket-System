# Copyright (c) 2024, Vikash Kumar and Contributors
# See license.txt

# import frappe
from frappe.tests.utils import FrappeTestCase


class TestFlightPassenger(FrappeTestCase):
	pass

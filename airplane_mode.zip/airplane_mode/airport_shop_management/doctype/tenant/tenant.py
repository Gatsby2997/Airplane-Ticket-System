# Copyright (c) 2024, Vikash Kumar and contributors
# For license information, please see license.txt

# import frappe
from frappe.model.document import Document


class Tenant(Document):
	pass
